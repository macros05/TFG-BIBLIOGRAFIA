import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Documento } from '../interfaces/document.interface';

@Injectable({
  providedIn: 'root'
})
export class DocumentoService {
  private apiUrl = 'http://127.0.0.1:8000';

  constructor(private http: HttpClient) {}

  buscarPorFiltros(filtros: {
    titulo?: string, autor?: string, familia?: string, genero?: string,
    especie?: string, palabras_clave?: string, distribucion?: string,
    page?: number, page_size?: number
  }): Observable<{ total: number, resultados: Documento[] }> {

    let params = new HttpParams();

    Object.entries(filtros).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        params = params.set(key, value.toString());
      }
    });

    return this.http.get<{ total: number, resultados: Documento[] }>(
      `${this.apiUrl}/documentos/buscar`, { params }
    );
  }
}
