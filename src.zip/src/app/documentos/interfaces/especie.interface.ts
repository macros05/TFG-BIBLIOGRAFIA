
export interface Especie {
  familia: string;
  genero: string;
  especie: string;
  distribucion: string;
}
