import { Component, HostListener, OnInit } from '@angular/core';
import { Documento } from '../../interfaces/document.interface';
import { DocumentoService } from '../../services/documentos.service';
import { debounceTime, distinctUntilChanged, Subject } from 'rxjs';
import {
  CommonModule
} from '@angular/common';
import {
  FormsModule
} from '@angular/forms';
import {
  MatInputModule
} from '@angular/material/input';
import {
  MatFormFieldModule
} from '@angular/material/form-field';
import {
  MatButtonModule
} from '@angular/material/button';
import {
  MatCardModule
} from '@angular/material/card';
import {
  MatProgressSpinnerModule
} from '@angular/material/progress-spinner';
import {
  MatIconModule
} from '@angular/material/icon';
import {
  MatListModule
} from '@angular/material/list';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatCardModule,
    MatProgressSpinnerModule,
    MatIconModule,
    MatListModule
  ]
})
export class SearchComponent implements OnInit {
  documentos: Documento[] = [];
  total = 0;
  page = 1;
  pageSize = 20;
  isLoading = false;
  isLoadingMore = false;
  noMoreResults = false;

  tituloBuscado = '';
  autorBuscado = '';
  familiaBuscada = '';
  generoBuscado = '';
  especieBuscada = '';
  palabrasClaveBuscadas = '';
  distribucionBuscada = '';
  error: string | null = null;

  trackById(index: number, item: Documento): number {
    return item.id;
  }

  private filtroSubject = new Subject<void>();

  constructor(private documentosService: DocumentoService) {}

  ngOnInit(): void {
    this.filtroSubject.pipe(debounceTime(500), distinctUntilChanged()).subscribe(() => {
      this.resetYBuscar();
    });

    this.resetYBuscar();
  }

  onFiltroChange(): void {
    this.page = 1;
    this.documentos = [];
    this.total = 0;
    this.noMoreResults = false;
    this.filtroSubject.next();
  }

  buscar(): void {
    this.error = null;

    if (this.page === 1) {
      this.isLoading = true;
    } else {
      if (this.noMoreResults) return;
      this.isLoadingMore = true;
    }

    this.documentosService.buscarPorFiltros({
      titulo: this.tituloBuscado,
      autor: this.autorBuscado,
      familia: this.familiaBuscada,
      genero: this.generoBuscado,
      especie: this.especieBuscada,
      palabras_clave: this.palabrasClaveBuscadas,
      distribucion: this.distribucionBuscada,
      page: this.page,
      page_size: this.pageSize
    }).subscribe({
      next: res => {
        if (this.page === 1) this.documentos = [];
        this.total = res.total || 0;
        this.documentos = [...this.documentos, ...res.resultados];
        this.noMoreResults = this.documentos.length >= this.total;
        this.isLoading = false;
        this.isLoadingMore = false;
      },
      error: err => {
        this.error = 'Error al cargar documentos';
        this.isLoading = false;
        this.isLoadingMore = false;
      }
    });
  }


  resetYBuscar(): void {
    this.documentos = [];
    this.page = 1;
    this.noMoreResults = false;
    this.buscar();
  }

  @HostListener('window:scroll', [])
  onScroll(): void {
    const threshold = 300;
    const position = window.innerHeight + window.scrollY;
    const height = document.documentElement.scrollHeight;

    if (position + threshold >= height && !this.isLoading && !this.isLoadingMore) {
      this.page++;
      this.buscar();
    }
  }

  getEspecies(doc: Documento): string {
    return doc.especies?.map(e =>
      `${e.familia || '?'} - ${e.genero || '?'} ${e.especie} (${e.distribucion || '?'})`
    ).join(', ') || 'No especificado';
  }
}
